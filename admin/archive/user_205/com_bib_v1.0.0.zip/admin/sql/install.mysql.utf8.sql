CREATE TABLE IF NOT EXISTS `#__bib_bbb` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (id)
)
CHARACTER SET utf8
COLLATE utf8_general_ci;
